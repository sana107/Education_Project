import React from 'react'
import './Footer.css'
export default function Footertop() {
    return (
        <>
            <footer>
                <div className="container-fluid">
                    <div className="footer-top px-1">
                        <div className="">
                            <h1 className=''>here we will add extra stuff and initiative time to time</h1>
                        </div>
                    </div>

                </div>
            </footer>
        </>
    )
}
